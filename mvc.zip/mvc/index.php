<?php

require_once 'config/global.php';


if(isset($_GET["controllers"])){
 
    $controllerObj=controlleR($_GET["controllers"]);

    launchAction($controllerObj);
}else{
    
    $controllerObj=controlleR(CONTROLLER);
  
    launchAction($controllerObj);
}


function controlleR($controller){
            $strFileController='controller/employeesController.php';
            require_once $strFileController;
            $controllerObj=new employeesController();

    return $controllerObj;
}

function launchAction($controllerObj){
    if(isset($_GET["action"])){
        $controllerObj->run($_GET["action"]);
    }else{
        $controllerObj->run(ACTION);
    }
}



?>