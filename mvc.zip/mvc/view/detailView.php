<!DOCTYPE HTML>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title>Example PHP+PDO+POO+MVC</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <style>
            input{
                margin-top:5px;
                margin-bottom:5px;
            }
            .right{
                float:right;
            }
        </style>
    </head>
    <body>
        <div class="col-lg-5 mr-auto" style="border:5px solid grey;border-radius:25px;padding:10px 20px;margin-left:25%;margin-top:10px;box-shadow: 5px 5px 5px 5px #888888;">
            <form action="index.php?controller=employees&action=Currentdata" method="post">
                <h3>Details</h3>
                <hr/>
                <input type="hidden" name="id" value="<?php echo $datos["employee"]->id ?>"/>
                Name: <input type="text" name="Name" value="<?php echo $datos["employee"]->Name ?>" class="form-control"/>
                Surname: <input type="text" name="Surname" value="<?php echo $datos['employee']->Surname ?>" class="form-control"/>
                Email: <input type="text" name="email" value="<?php echo $datos['employee']->email ?>" class="form-control"/>
                phone: <input type="text" name="phone" value="<?php echo$datos['employee']->phone ?>" class="form-control"/>
                <h4 style="font-size:20px;">Birthday: </h4><div class="col-lg-4">
           <select name="Day" value="<?php echo $datos['employee']->Day ?>" style="padding:10px 20px;margin-left:30%;border:2px solid grey;border-radius:10px;">
           <?php 
           echo "<option>".$datos['employee']->Day."</option>";
           for($i=0;$i<=31;$i++)
           {
               
               echo "<option>".$i."</option>";
           }
           
           
           ?>
           </select>
           </div>
            <div class="col-lg-4">
            <select name="Month" value="<?php echo $datos['employee']->Month ?>" style="padding:10px 20px;margin-left:20%;border:2px solid grey;border-radius:10px;">
           <?php 
           $m=array("Januaray","February","March","April","May","June","July","August","September","October","November","December");
           echo "<option>".$datos['employee']->Month."</option>";
           for($i=0;$i<=12;$i++)
           {
               echo "<option >".$m[$i]."</option>";
           }
           
           
           ?>
           </select>
            </div>
            <div class="col-lg-4">
            <select name="Year"  value="<?php echo $datos['employee']->Year ?>" style="padding:10px 20px;margin-left:30%;border:2px solid grey;border-radius:10px;">
           <?php 
           echo  $datos['employee']->Year;
           //$m=array("Januaray","February","March","April","May","June","July","August","September","October","November","December");
           for($i=1999;$i<=2021;$i++)
           {
               echo "<option >".$i."</option>";
           }
           
           
           ?>
           </select>
            </div>
        
                <label style="margin-top:20px;font-size:25px;margin-bottom:20px;color:green;margin-right:25px;">Gender :</label>
                <fieldset  style="width: 20px;border-radius: 8px; margin-left:25%;font-size:18px; ">
                    <input type="radio" class="radio" id="Male" name="Gender" value="Male" <?php echo ($datos['employee']->Gender =="Male") ? 'checked' : ''; ?> required />    Male  
                
                
                    <input type="radio" class="radio" id="Female" name="Gender" value="Female" <?php echo ($datos['employee']->Gender =="Female") ? 'checked' : ''; ?> required />    Female
            
                
                    <input type="radio" class="radio" id="Custom" name="Gender" value="Custom" <?php echo ($datos['employee']->Gender =="Custom") ? 'checked' : '';  ?> required />    Custom
                </fieldset>
                <input style="margin-left:50px;" type="submit"  value="Update" class="btn btn-success"/>
                <a href="index.php" class="btn btn-info "  style="margin-left:50%;margin-top:8px;padding:8px 10px;">Cancel</a>
            </form>
        
           
        </div>
       
    </body>
</html> 