<!DOCTYPE HTML>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title>Example PHP+PDO+POO+MVC</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="sweetalert.css" type="text/css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="sweetalert.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <style>
            input{
                margin-top:5px;
                margin-bottom:5px;
            }
            .right{
                float:right;
            }
            
        #table tr > td 
            {
                border:2px solid green;
                border-radius:5px;
                padding:10px;
            } 
            th{
                text-align: center;
                color: green;
            }


        </style>
    </head>
    <body>
        <form action="index.php?controller=employees&action=create" method="post" class="col-lg-4 " style="border:5px solid grey;border-radius:20px;margin-top:20px;margin-left:20px;margin-right-10px;padding-bottom:20px;padding-right:20px;box-shadow: 5px 5px 5px 0px grey;">
            <h3 style="color:green;">Form</h3>
            <hr/>
            Name: <input type="text" name="Name" class="form-control" required/>
            Surname: <input type="text" name="Surname" class="form-control" required/>
            Email: <input type="email" name="email" class="form-control" required/>
            phone: <input type="text" name="phone" class="form-control" required/>
            
            <br>
            <label style="margin-top:0px;font-size:25px;margin-bottom:10px;color:green;">Birthday :</label>
            <br>
            <div class="col-lg-4">
           <select name="Day" style="padding:10px 30px;margin-left:30%;border:2px solid grey;border-radius:10px;">
           <?php 
           for($i=0;$i<=31;$i++)
           {
               echo "<option >".$i."</option>";
           }
           
           
           ?>
           </select>
            </div>
            <div class="col-lg-4">
            <select name="Month" style="padding:10px 20px;margin-left:15%;border:2px solid grey;border-radius:10px;">
           <?php 
           $m=array("Januaray","February","March","April","May","June","July","August","September","October","November","December");
           for($i=0;$i<=12;$i++)
           {
               echo "<option >".$m[$i]."</option>";
           }
           
           
           ?>
           </select>
            </div>
            <div class="col-lg-4">
            <select name="Year" style="padding:10px 25px;margin-left:25%;border:2px solid grey;border-radius:10px;">
           <?php 
           //$m=array("Januaray","February","March","April","May","June","July","August","September","October","November","December");
           for($i=1999;$i<=2021;$i++)
           {
               echo "<option >".$i."</option>";
           }
           
           
           ?>
           </select>
            </div>
        
            
            <label style="margin-top:20px;font-size:25px;margin-bottom:20px;color:green;margin-right:25px;">Gender :</label>
            <div style="margin-left:20%;font-size:20px;">
             <input style="margin-left:15%;" type="radio"  name="Gender" value="Male">      Male
            <br>
             <input type="radio" style="margin-left:15%;"  name="Gender" value="Female">    Female
             <br>
             <input type="radio"  style="margin-left:15%;" name="Gender" value="Custom">    Custom
            </div>
            <?php
            /*
<div>
            <select  name ="Date" style="margin-left:15%;border:2px solid grey;border-radius:5px;padding:5px 15px;">
                <?php
            //     for($i=0;$i<=31;$i++)

            //    echo  "<option>".$i."</option>";

                ?>
            </select>
            <select name ="Month" style="margin-left:15%;border:2px solid grey;border-radius:5px;padding:5px 15px;">
            
            <?php
        //     $m=array("january","February","March","April","May","June","july",
        //     "August","September","October","November","December");
        //     for($i=0;$i<12;$i++)

        //    echo  "<option>".$m[$i]."</option>";

                    ?>
            </select>
            <select  name ="Year" style="margin-left:15%;border:2px solid grey;border-radius:5px;padding:5px 15px;">
            <?php
            //     for($i=1999;$i<=2021;$i++)

            //    echo  "<option>".$i."</option>";

                
            </select>
            </div>
            */
            ?>
       <p> By clicking Sign Up, you agree to our <a href="">Terms</a>, <a href="">Data Policy</a> and <a href="">Cookie Policy</a>. You may receive SMS notifications from us and can opt out at any time.</p>
          <div style="margin-left:40%;">  <input type="submit" value="Save" class="btn btn-success" required/> </div>
        </form>
        
        <div class="col-lg-7" style="border:5px solid grey;padding: 10px 20px;border-radius:20px;margin-left:40px;margin-top:20px;box-shadow: 5px 0px 5px 2px #888888;">
            <h3 style="color:green;font-size:30px;text-align:center;">Users List</h3>
            <hr/>
        
    
        <section class="col-lg-12 usuario" >
    
        <table id="table"  style="border:2px solid green;border-radius:5px;">
        <!-- <tr>
        <td>Name</td>
        <td>Surname</td>
        <td>Email</td>
        <td>Phone</td>
        <td>Day</td>
        <td>Month</td>
        <td>Year</td>
        <td>Gender</td>
        
        </tr>
     -->
          
               
                <th>Name</th>
                <th>Surname</th>
                <th>Email</th>
                <th>Phone</th>
                <!-- <th>Day</th>
                <th>Month</th>
                <th>Year</th> -->
                <th>Birthday</th>
                <th>Gender</th>
                <th>Action</th>


           <?php   foreach($datos["employees"] as $employee) {
           
                ?>
                
                <tr > <?php //echo $employee["id"]; ?>
          
            <td >  <?php echo $employee["Name"]; ?> </td>
            <td> <?php echo $employee["Surname"]; ?></td>
            <td>  <?php echo $employee["email"]; ?></td>
            <td><?php echo $employee["phone"]; ?></td>
            <td> <?php echo $employee["Year"]."-".$employee["Month"]."-".$employee["Day"]; ?></td>
          <?php //echo $employee["Month"]; ?>
             <?php// echo $employee["Year"]; ?> 
        
            <td> <?php echo $employee["Gender"]; ?></td>
            <td><a href="index.php?controller=employees&action=detail&id=<?php echo $employee['id']; ?>" class="btn btn-success">Edit</a></td>
 
                </tr>
                <?php } ?>
                </table >
               
                <hr/>
               
                
            
            
        </section> 
        </div>
        
	
        
        
    </body>
</html>