<?php
define("CONTROLLER", "employeesController");
define("ACTION", "index");
?>