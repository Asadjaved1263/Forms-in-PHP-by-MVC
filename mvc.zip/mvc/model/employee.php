<?php
class Employee {
    private $table = "employees";
    private $Connection;

    private $id;
    private $Name;
    private $Surname;
    private $email;
    private $phone;
    private $Day;
    private $Month;
    private $Year;
    private $Gender;

    public function __construct($Connection) {
		$this->Connection = $Connection;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }
    
    public function getName() {
        return $this->Name;
    }

    public function setName($Name) {
        $this->Name = $Name;
    }

    public function getSurname() {
        return $this->Surname;
    }

    public function setSurname($Surname) {
        $this->Surname = $Surname;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getphone() {
        return $this->phone;
    }

    public function setphone($phone) {
        $this->phone = $phone;
    }
    public function getDay() {
        return $this->Day;
    }

    public function setDay($Day) {
        $this->Day = $Day;
    }

//------
    public function getMonth() {
        return $this->Month;
    }

    public function setMonth($Month) {
        $this->Month = $Month;
    }

    //--
    public function getYear() {
        return $this->Year;
    }

    public function setYear($Year) {
        $this->Year = $Year;
    }
    
//
public function getGender() {
    return $this->Gender;
}

public function setGender($Gender) {
    $this->Gender = $Gender;
}


    public function save(){

        $exe = $this->Connection->prepare("INSERT INTO " . $this->table . " (Name,Surname,email,phone,Day,Month,Year,Gender)
                                        VALUES (:Name,:Surname,:email,:phone,:Day,:Month,:Year,:Gender)");
        $result = $exe->execute(array(
            "Name" => $this->Name,
            "Surname" => $this->Surname,
            "email" => $this->email,
            "phone" => $this->phone,
            "Day" => $this->Day,
            "Month" => $this->Month,
            "Year" => $this->Year,
            "Gender" => $this->Gender

        ));
        $this->Connection = null;

        return $result;
    }

    public function update(){

        $exe = $this->Connection->prepare("
            UPDATE " . $this->table . " 
            SET 
                Name = :Name,
                Surname = :Surname, 
                email = :email,
                phone = :phone,
                Day = :Day,
                Month = :Month,
                Year = :Year,
                Gender = :Gender
            WHERE id = :id 
        ");

        $result = $exe->execute(array(
            "id" => $this->id,
            "Name" => $this->Name,
            "Surname" => $this->Surname,
            "email" => $this->email,
            "phone" => $this->phone,
            "Day" => $this->Day,
            "Month" => $this->Month,
            "Year" => $this->Year,
            "Gender" => $this->Gender
        ));
        $this->Connection = null;

        return $result;
    }
        
    
    public function getAll(){

        $exe = $this->Connection->prepare("SELECT id,Name,Surname,email,phone,Day,Month,Year,Gender FROM " . $this->table);
        $exe->execute();
       
        $result = $exe->fetchAll();
        $this->Connection = null; 
        return $result;

    }
    
    
    public function getById($id){
        $exe = $this->Connection->prepare("SELECT id,Name,Surname,email,phone,Day,Month,Year,Gender 
                                                FROM " . $this->table . "  WHERE id = :id");
        $exe->execute(array(
            "id" => $id
        ));
      
        $result = $exe->fetchObject();
        $this->Connection = null; 
        return $result;
    }
    
    public function getBy($column,$value){
        $exe = $this->Connection->prepare("SELECT id,Name,Surname,email,phone ,Day,Month,Year,Gender
                                                FROM " . $this->table . " WHERE :column = :value");
        $exe->execute(array(
            "column" => $column,
            "value" => $value
        ));
        $result = $exe->fetchAll();
        $this->Connection = null;
        return $result;
    }
    
    public function deleteById($id){
        try {
            $exe = $this->Connection->prepare("DELETE FROM " . $this->table . " WHERE id = :id");
            $exe->execute(array(
                "id" => $id
            ));
            $Connection = null;
        } catch (Exception $e) {
            echo 'Failed DELETE (deleteById): ' . $e->getMessage();
            return -1;
        }
    }
    
    public function deleteBy($column,$value){
        try {
            $exe = $this->Connection->prepare("DELETE FROM " . $this->table . " WHERE :column = :value");
            $exe->execute(array(
                "column" => $value,
                "value" => $value,
            ));
            $Connection = null;
        } catch (Exception $e) {
            echo 'Failed DELETE (deleteBy): ' . $e->getMessage();
            return -1;
        }
    }
    
}
?>