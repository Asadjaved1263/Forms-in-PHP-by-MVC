<?php
class EmployeesController{

    private $conectar;
    private $Connection;

    public function __construct() {
		require_once  __DIR__ . "/../core/Conectar.php";
        require_once  __DIR__ . "/../model/employee.php";
        
        $this->conectar=new Conectar();
        $this->Connection=$this->conectar->Connection();

    }

    public function run($action){
        switch($action)
        { 
            case "index" :
                $this->index();
                break;
            case "create" :
                $this->create();
                break;
            case "detail" :
                $this->detail();
                break;
            case "Currentdata" :
                $this->Currentdata();
                break;
            default:
                $this->index();
                break;
        }
    }
    
   
    public function index(){
        
        $employee=new Employee($this->Connection);
        $employees=$employee->getAll();
       
        $this->view("index",array(
            "employees"=>$employees,
            "title" => "PHP MVC"
        ));
    }

    
    public function detail(){
        
        $model = new Employee($this->Connection);

        $employee = $model->getById($_GET["id"]);

        $this->view("detail",array(
            "employee"=>$employee,
            "title" => "Detail Employee"
        ));
    }
    
   
    public function create(){
        if(isset($_POST["Name"])){
            
            
            $employee=new Employee($this->Connection);
            $employee->setName($_POST["Name"]);
            $employee->setSurname($_POST["Surname"]);
            $employee->setEmail($_POST["email"]);
            $employee->setphone($_POST["phone"]);
            $employee->setDay($_POST["Day"]);
            $employee->setMonth($_POST["Month"]);
            $employee->setYear($_POST["Year"]);
            $employee->setGender($_POST["Gender"]);
            $save=$employee->save();
        }
        header('Location: index.php');
    }
    
    public function Currentdata(){
        if(isset($_POST["id"])){
            
            //We create a user
            $employee=new Employee($this->Connection);
            $employee->setId($_POST["id"]);
            $employee->setName($_POST["Name"]);
            $employee->setSurname($_POST["Surname"]);
            $employee->setEmail($_POST["email"]);
            $employee->setphone($_POST["phone"]);
            $employee->setDay($_POST["Day"]);
            $employee->setMonth($_POST["Month"]);
            $employee->setYear($_POST["Year"]);
            $employee->setGender($_POST["Gender"]);
            $save=$employee->update();
        }
        header('Location: index.php');
    }
    
    
   /**
    * Create the view that we pass to it with the indicated data.
    *
    */
    public function view($vista,$datos){
        $data = $datos;  
        require_once  __DIR__ . "/../view/" . $vista . "View.php";

    }

}
?>